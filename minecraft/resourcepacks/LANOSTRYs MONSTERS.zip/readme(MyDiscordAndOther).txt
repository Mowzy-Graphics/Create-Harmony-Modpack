Thanks for using my resourcepack!

Terms of use

 I forbid you to use my resourcepacks/mods for commercial purposes,
 to use them in third-party projects, paid modpacks,
 on public servers with paid pass or donation,
 as well as to distribute them on other sites It is also forbidden
 to use textures from my projects for training neural networks
If you want to use my projects in your modpacks, 
you must credit me as the author and share a portion 
of the revenue from downloads
For other uses (videos, articles, etc.), 
please provide a link to the download (modrinth or curseforge)
All of this works with the full or modified package, 
as well as if you use only part of the content

If you are interested in my services as a texturer or modeller,
you can go to my discord: (I also look forward to hearing from you for 
communication or ideas for future projects.)

https://discord.gg/mThvczzpuV

Donation and exclusive content: 

https://boosty.to/lanostry

<3
